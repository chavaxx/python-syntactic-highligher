[
  inputs: [
    "lib/**/*.{ex,exs}",
    "test/**/*.{ex,exs}",
    "mix/**/*.{ex,exs}",
    "./mix.exs",
  ]
]

